package com.cts.FlightReservation.FlightReservation;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FlightReservation {
	public static void main(String args[])
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Shubham Kumar Gupta\\Downloads\\chromedriver_win32\\chromedriver.exe" );
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.newtours.demoaut.com/");
		System.out.println("Url is launched successfully");
		driver.findElement(By.name("userName")).sendKeys("mercury");
		driver.findElement(By.name("password")).sendKeys("mercury");
		driver.findElement(By.name("login")).click();
		System.out.println("login is done successfull");
		String title = driver.getTitle();
		if(title.contentEquals("Find a Flight: Mercury Tours:"))
		{
			System.out.println("Test case passed");
		}
		else
		{
			System.out.println("Test case not passed");
		}
		
		//passenger count
		WebElement number = driver.findElement(By.name("passCount"));
		Select pass = new Select(number);
		pass.selectByVisibleText("2");
		
		//Departing from
		Select depart= new Select(driver.findElement(By.name("fromPort")));
		depart.selectByVisibleText("Frankfurt");
		
		//name of month
		Select on = new Select(driver.findElement(By.name("fromMonth")));
		on.selectByVisibleText("May");
		
		//Arriving in
		Select arrive = new Select(driver.findElement(By.name("toPort")));
		arrive.selectByVisibleText("New York");
		
		//Returning
		Select retur = new Select(driver.findElement(By.name("toMonth")));
		retur.selectByVisibleText("June");
		
		//Preference
		driver.findElement(By.xpath(".//input[@name='servClass' and @value='Business']")).click();
		
		//Airline
		Select airline = new Select(driver.findElement(By.name("airline")));
		airline.selectByVisibleText("Blue Skies Airlines");
		
		//find booking
		driver.findElement(By.name("findFlights")).click();
		System.out.println("you have clicked on the buttom to find flight");
		
		// select flight for depart
		List<WebElement> departFlight = driver.findElements(By.xpath(".//input[@name='outFlight']"));
		departFlight.get(2).click();
		
		//select flight for return
		List<WebElement> returnFlight = driver.findElements(By.xpath(".//input[@name='inFlight']"));
		returnFlight.get(1).click();
		
		//continue buttom
		driver.findElement(By.name("reserveFlights")).click();
		System.out.println("Continue buttom is clicked on the select flight page");
		
		
		//passenger information
		
		driver.findElement(By.name("passFirst0")).sendKeys("shubham");
		
		driver.findElement(By.name("passLast0")).sendKeys("kumar");
		
		Select meal = new Select(driver.findElement(By.name("pass.0.meal")));
		meal.selectByVisibleText("Low Calorie");
		
		
		driver.findElement(By.name("passFirst1")).sendKeys("Mohit");
		
		driver.findElement(By.name("passLast1")).sendKeys("Mishra");
		
		Select meal1 = new Select(driver.findElement(By.name("pass.0.meal")));
		meal1.selectByVisibleText("Low Sodium");
		
		driver.findElement(By.name("creditnumber")).sendKeys("123456789");
		System.out.println("Credit number entered");
		
		driver.findElement(By.name("buyFlights")).click();
		System.out.println("purchase buttom clicked");
		System.out.println("your ticket is booked");
		
//		if(driver.getCurrentUrl().contentEquals("https://newtours.demoaut.com/mercurypurchase2.php"))
//		{
//			System.out.println("Pass : flight reservation is successfull");
//		}
//		else
//		{
//			System.out.println("Fail : flight reservation is not successfull");
//		}
		
	
		
	}
		
	 

}
